const { Router } = require("express");
const { validateJWT } = require("../middlewares/validateJWT");
const {
	updateRecord,
	saveRecord,
	getRecord,
	deleteRecord,
	statusRecord,
	getHistory,
	upload,
} = require("../controllers/pets");


const router = Router();
/**
 * Middleware all routes
 */

 router.post("/status", statusRecord);


router.use(validateJWT);

router.get("/", getRecord);


router.post("/", saveRecord);
router.post("/upload", upload);

router.put("/:id", updateRecord);

router.delete("/:id", deleteRecord);

router.get("/getHistory", getHistory);

module.exports = router;